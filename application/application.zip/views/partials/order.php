<div class="ordercard">
    <table>
    <tr>
        <td>
            <span class="id"></span>
        </td>
        <td>
            <span class="name"></span>
        </td>
        <td>
            <span class="email"></span>
        </td>
        <td>
            <span class="status"></span>
        </td>
        <td>
            <span class="finalamount"></span>
        </td>
        <td>
            <span class="timestamp"></span>
        </td>
    </tr>
    </table>
    
    <table>
        <thead>
            <tr>
                <th>Product
                </th>
                <th>Amount
                </th>
                <th>Quantity
                </th>
                <th>Total Amount
                </th>
            </tr>
        </thead>
        <tbody>
            <tr class="repeat">
                <td>Product
                </td>
                <td>Amount
                </td>
                <td>Quantity
                </td>
                <td>Total Amount
                </td>
            </tr>
        </tbody>
    </table>
</div>
