<html>
<head>
<title> selfcareindia.com</title>
</head>
<body>
<center>
<?php include('Crypto.php')?>
<?php

	error_reporting(0);

	$working_key='109F1D878C73307DA83F8714A2F71048';//Shared by CCAVENUES
	$access_code='AVVX64DD83AW04XVWA';//Shared by CCAVENUES
	$merchant_data='14857';

	foreach ($_POST as $key => $value){
		$merchant_data.=$key.'='.$value.'&';
	}

	$encrypted_data=encrypt($merchant_data,$working_key); // Method for encrypting the data.

	$production_url='https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction&encRequest='.$encrypted_data.'&access_code='.$access_code;
?>


<script type="text/javascript" src="jquery-1.7.2.js"></script>
<script type="text/javascript">
    	$(document).ready(function(){
window.location.href="<?php echo $production_url;?>";
    		 window.addEventListener('message', function(e) {
		    	 $("#paymentFrame").css("height",e.data['newHeight']+'px');
		 	 }, false);

		});
</script>
</center>
</body>
</html>
